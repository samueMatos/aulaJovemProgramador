package com.senac.aulaapijovemprogramador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AulaapijovemprogramadorApplicationTests {

	@Test
	void contextLoads() {
	}

}
