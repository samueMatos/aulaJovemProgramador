package com.senac.aulaapijovemprogramador.dto;

public record LoginRequestDto (String email, String senha) {
}
