package com.senac.aulaapijovemprogramador.dto;

public record UsuarioCriarRequestDto (String nome, String email, String senha, String cpf){
}
