package com.senac.aulaapijovemprogramador.model.interfaces;

public interface INotificacao {

    void Enviar(String mensagem);

}
